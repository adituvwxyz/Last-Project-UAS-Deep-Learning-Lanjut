require('dotenv').config();
const express = require('express');
const path = require('path');
const chatRoutes = require('./routes/chat');
const campusConfig = require('./config/campusConfig');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// View engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Make config available to all views
app.use((req, res, next) => {
    res.locals.config = campusConfig;
    res.locals.campusName = campusConfig.campusName;
    res.locals.campusShortName = campusConfig.campusShortName;
    next();
});

// Routes
app.get('/', (req, res) => {
    res.render('index', {
        title: `Beranda - ${campusConfig.campusName}`
    });
});

app.get('/tentang', (req, res) => {
    res.render('tentang', {
        title: `Tentang - ${campusConfig.campusName}`
    });
});

app.get('/program', (req, res) => {
    res.render('program', {
        title: `Program Studi - ${campusConfig.campusName}`
    });
});

app.get('/fasilitas', (req, res) => {
    res.render('fasilitas', {
        title: `Fasilitas - ${campusConfig.campusName}`
    });
});

app.get('/kontak', (req, res) => {
    res.render('kontak', {
        title: `Kontak - ${campusConfig.campusName}`
    });
});

// API Routes
app.use('/api', chatRoutes);

// API endpoint for contact form
app.post('/api/contact', async (req, res) => {
    const { name, email, phone, subject, message } = req.body;
    
    try {
        // Here you can save to database
        // For now, just return success
        console.log('Contact form submission:', { name, email, phone, subject, message });
        
        res.json({
            success: true,
            message: 'Pesan berhasil dikirim!'
        });
    } catch (error) {
        console.error('Error saving contact:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan. Silakan coba lagi.'
        });
    }
});

// API endpoint for registration form
app.post('/api/register', async (req, res) => {
    const { name, email, phone, program } = req.body;
    
    try {
        // Here you can save to database
        console.log('Registration submission:', { name, email, phone, program });
        
        res.json({
            success: true,
            message: 'Pendaftaran berhasil! Kami akan menghubungi Anda segera.'
        });
    } catch (error) {
        console.error('Error saving registration:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan. Silakan coba lagi.'
        });
    }
});

// 404 page
app.use((req, res) => {
    res.status(404).render('404', {
        title: 'Halaman Tidak Ditemukan'
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Server berjalan di http://localhost:${PORT}`);
    console.log(`📚 Website Kampus siap digunakan!`);
});
