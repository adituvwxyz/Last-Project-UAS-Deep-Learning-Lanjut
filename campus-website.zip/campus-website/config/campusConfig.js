module.exports = {
    // Informasi Kampus
    campusName: 'Universitas Teknologi Nusantara',
    campusShortName: 'UTN',
    foundingYear: 2010,
    tagline: 'Membangun Generasi Unggul dan Berkarakter',
    
    // Visi
    vision: 'Menjadi universitas terkemuka yang menghasilkan lulusan berkualitas, inovatif, dan berdaya saing global pada tahun 2030.',
    
    // Misi
    mission: [
        'Menyelenggarakan pendidikan berkualitas berbasis teknologi dan inovasi',
        'Mengembangkan penelitian yang relevan dengan kebutuhan industri dan masyarakat',
        'Melaksanakan pengabdian masyarakat untuk meningkatkan kesejahteraan bangsa',
        'Membangun kemitraan strategis dengan berbagai institusi nasional dan internasional',
        'Menciptakan lingkungan akademik yang kondusif untuk pengembangan karakter mahasiswa'
    ],
    
    // Nilai-Nilai
    values: [
        {
            title: 'Integritas',
            description: 'Menjunjung tinggi kejujuran, transparansi, dan akuntabilitas dalam setiap tindakan',
            icon: 'fas fa-shield-alt'
        },
        {
            title: 'Inovasi',
            description: 'Mendorong kreativitas dan pemikiran out-of-the-box untuk solusi masa depan',
            icon: 'fas fa-lightbulb'
        },
        {
            title: 'Kolaborasi',
            description: 'Membangun kerjasama yang saling menguntungkan dengan berbagai pihak',
            icon: 'fas fa-handshake'
        },
        {
            title: 'Keunggulan',
            description: 'Berkomitmen untuk mencapai standar tertinggi dalam setiap aspek',
            icon: 'fas fa-trophy'
        },
        {
            title: 'Kepedulian',
            description: 'Peduli terhadap lingkungan, masyarakat, dan kesejahteraan bersama',
            icon: 'fas fa-heart'
        },
        {
            title: 'Profesionalisme',
            description: 'Menjalankan tugas dengan kompetensi, dedikasi, dan tanggung jawab',
            icon: 'fas fa-briefcase'
        }
    ],
    
    // Statistik
    stats: {
        students: 5000,
        lecturers: 200,
        programs: 12,
        awards: 50
    },
    
    // Kontak
    contact: {
        address: 'Jl. Teknologi No. 123, Bandung, Jawa Barat 40132',
        phone: '(022) 1234-5678',
        email: 'info@utn.ac.id',
        whatsapp: '+62 812-3456-7890'
    },
    
    // Social Media
    socialMedia: {
        instagram: 'https://instagram.com/utn_official',
        facebook: 'https://facebook.com/utn.official',
        twitter: 'https://twitter.com/utn_official',
        youtube: 'https://youtube.com/@utn_official',
        linkedin: 'https://linkedin.com/school/utn'
    },
    
    // Theme Colors
    theme: {
        primary: '#667eea',
        secondary: '#f093fb',
        accent: '#4facfe'
    },
    
    // Fitur Website
    features: [
        {
            title: 'Pendaftaran Online',
            description: 'Daftar kuliah dengan mudah dan cepat melalui sistem online kami',
            icon: 'fas fa-file-alt'
        },
        {
            title: 'E-Learning',
            description: 'Platform pembelajaran digital yang modern dan interaktif',
            icon: 'fas fa-laptop'
        },
        {
            title: 'Konsultasi AI',
            description: 'Chatbot cerdas untuk menjawab pertanyaan Anda 24/7',
            icon: 'fas fa-robot'
        },
        {
            title: 'Akreditasi A',
            description: 'Semua program studi terakreditasi A oleh BAN-PT',
            icon: 'fas fa-certificate'
        }
    ],
    
    // Program Studi
    programs: [
        {
            id: 1,
            name: 'Teknik Informatika',
            degree: 'S1',
            description: 'Program studi yang mempelajari pengembangan software, AI, dan teknologi informasi terkini',
            icon: 'fas fa-code',
            duration: '4 Tahun',
            credits: '144 SKS',
            accreditation: 'A',
            prospects: [
                'Software Engineer',
                'Data Scientist',
                'AI Specialist',
                'System Analyst'
            ]
        },
        {
            id: 2,
            name: 'Sistem Informasi',
            degree: 'S1',
            description: 'Menggabungkan teknologi informasi dengan manajemen bisnis untuk solusi digital',
            icon: 'fas fa-database',
            duration: '4 Tahun',
            credits: '144 SKS',
            accreditation: 'A',
            prospects: [
                'Business Analyst',
                'IT Consultant',
                'System Manager',
                'ERP Specialist'
            ]
        },
        {
            id: 3,
            name: 'Desain Komunikasi Visual',
            degree: 'S1',
            description: 'Mengembangkan kreativitas dalam desain grafis, multimedia, dan komunikasi visual',
            icon: 'fas fa-palette',
            duration: '4 Tahun',
            credits: '144 SKS',
            accreditation: 'A',
            prospects: [
                'Graphic Designer',
                'UI/UX Designer',
                'Creative Director',
                'Multimedia Artist'
            ]
        },
        {
            id: 4,
            name: 'Manajemen Bisnis',
            degree: 'S1',
            description: 'Mempelajari strategi bisnis, kewirausahaan, dan manajemen organisasi modern',
            icon: 'fas fa-chart-line',
            duration: '4 Tahun',
            credits: '144 SKS',
            accreditation: 'A',
            prospects: [
                'Business Manager',
                'Entrepreneur',
                'Marketing Manager',
                'HR Manager'
            ]
        }
    ],
    
    // Fasilitas
    facilities: [
        {
            id: 1,
            name: 'Perpustakaan Digital',
            description: 'Perpustakaan modern dengan koleksi buku digital dan ruang baca yang nyaman',
            icon: 'fas fa-book-reader',
            image: 'library.jpg'
        },
        {
            id: 2,
            name: 'Laboratorium Komputer',
            description: 'Lab komputer dengan perangkat terkini untuk praktikum dan penelitian',
            icon: 'fas fa-desktop',
            image: 'lab.jpg'
        },
        {
            id: 3,
            name: 'Auditorium',
            description: 'Ruang serbaguna berkapasitas 500 orang untuk berbagai acara',
            icon: 'fas fa-building',
            image: 'auditorium.jpg'
        },
        {
            id: 4,
            name: 'Studio Multimedia',
            description: 'Studio lengkap untuk produksi konten multimedia dan broadcasting',
            icon: 'fas fa-video',
            image: 'studio.jpg'
        },
        {
            id: 5,
            name: 'Lapangan Olahraga',
            description: 'Fasilitas olahraga lengkap untuk berbagai aktivitas fisik',
            icon: 'fas fa-futbol',
            image: 'sport.jpg'
        },
        {
            id: 6,
            name: 'Kantin Modern',
            description: 'Area makan dengan berbagai pilihan menu sehat dan lezat',
            icon: 'fas fa-utensils',
            image: 'canteen.jpg'
        },
        {
            id: 7,
            name: 'Co-Working Space',
            description: 'Ruang kerja bersama yang nyaman untuk diskusi dan kolaborasi',
            icon: 'fas fa-users',
            image: 'coworking.jpg'
        },
        {
            id: 8,
            name: 'Innovation Hub',
            description: 'Pusat inovasi dan inkubator startup untuk mahasiswa',
            icon: 'fas fa-rocket',
            image: 'innovation.jpg'
        }
    ]
};
