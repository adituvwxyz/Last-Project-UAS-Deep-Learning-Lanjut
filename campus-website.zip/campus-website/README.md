# 🎓 Website Kampus Modern dengan AI Chatbot
### Version 3.0 - Ultra Modern Edition

Website kampus yang modern dan responsif dengan fitur chatbot AI menggunakan Groq API.

---

## ✨ **FITUR UTAMA**

### 🎨 **Design Modern**
- ✅ Glassmorphism effect (transparan blur)
- ✅ Gradient background yang cantik
- ✅ Animasi smooth dan interaktif
- ✅ Fully responsive (mobile-friendly)
- ✅ Modern cards dengan hover effects

### 📄 **Halaman Lengkap**
1. **Beranda** - Hero section, fitur unggulan, statistik, form pendaftaran
2. **Tentang** - Sejarah, visi-misi, nilai-nilai, timeline, statistik
3. **Program Studi** - Detail lengkap 4 program studi dengan prospek karir
4. **Fasilitas** - 8+ fasilitas kampus dengan deskripsi lengkap
5. **Kontak** - Form kontak, map, social media, FAQ

### 🤖 **AI Chatbot**
- Powered by Groq API (super cepat!)
- Model: Llama 3.3 70B Versatile
- Chatbot khusus untuk kampus
- Floating button di pojok kanan bawah
- Typing indicator
- Responsive chat window

### ⚙️ **Konfigurasi Mudah**
- Semua setting di 1 file: `config/campusConfig.js`
- Ubah nama kampus dalam 1 menit
- Customize warna tema
- Edit kontak, visi, misi
- Tambah/edit program & fasilitas

---

## 🚀 **INSTALASI**

### **Persyaratan Sistem**
- Node.js v14+ (Download: https://nodejs.org)
- NPM (included with Node.js)
- Text editor (VS Code recommended)
- Browser modern (Chrome, Firefox, Edge)

### **Langkah Instalasi**

#### **1. Install Node.js**
```bash
# Cek apakah sudah terinstall
node --version
npm --version
```

Jika belum, download dan install dari: https://nodejs.org

#### **2. Extract Project**
Extract file ZIP ke folder pilihan Anda

#### **3. Install Dependencies**
```bash
# Masuk ke folder project
cd campus-website-v3

# Install semua dependencies
npm install
```

#### **4. Setup Groq API Key**

1. Buka browser, kunjungi: https://console.groq.com/
2. Sign Up / Login (GRATIS dengan Google Account)
3. Klik **"API Keys"** → **"Create API Key"**
4. Copy API Key yang muncul (format: `gsk_xxxxx...`)
5. Edit file `.env`:
   ```env
   PORT=3000
   GROQ_API_KEY=gsk_paste_api_key_disini
   GROQ_API_URL=https://api.groq.com/openai/v1/chat/completions
   ```

#### **5. Jalankan Server**
```bash
npm start
```

#### **6. Buka Browser**
```
http://localhost:3000
```

---

## 🎨 **CARA UBAH NAMA KAMPUS**

### **SANGAT MUDAH! Hanya 3 langkah:**

1. Buka file: `config/campusConfig.js`

2. Edit bagian ini:
```javascript
campusName: 'Universitas Teknologi Nusantara',  // ← UBAH
campusShortName: 'UTN',                         // ← UBAH
```

Contoh ubah jadi "Universitas Indonesia":
```javascript
campusName: 'Universitas Indonesia',
campusShortName: 'UI',
```

3. Save & Restart server:
```bash
# Tekan Ctrl+C untuk stop
npm start
```

**DONE!** ✅ Nama kampus berubah di SEMUA halaman!

---

## 🎨 **CARA UBAH WARNA TEMA**

Edit file: `config/campusConfig.js`

```javascript
theme: {
    primary: '#667eea',      // Warna utama
    secondary: '#f093fb',    // Warna sekunder  
    accent: '#4facfe',       // Warna aksen
}
```

**Contoh Warna:**
- Biru Modern: `#2563eb`
- Hijau Fresh: `#059669`
- Ungu Elegan: `#7c3aed`
- Merah Bold: `#dc2626`

---

## 📁 **STRUKTUR PROJECT**

```
campus-website-v3/
├── config/
│   └── campusConfig.js       ← UBAH NAMA KAMPUS DI SINI
├── public/
│   ├── css/
│   │   └── style.css
│   └── js/
│       ├── main.js
│       └── contact.js
├── routes/
│   └── chat.js              ← Groq API integration
├── views/
│   ├── partials/
│   │   ├── header.ejs
│   │   ├── footer.ejs
│   │   └── chatbot.ejs
│   ├── index.ejs            ← Beranda
│   ├── tentang.ejs          ← Tentang (baru!)
│   ├── program.ejs          ← Program Studi (baru!)
│   ├── fasilitas.ejs        ← Fasilitas (baru!)
│   ├── kontak.ejs           ← Kontak (baru!)
│   └── 404.ejs
├── .env                      ← API Key Groq
├── server.js
├── package.json
└── README.md
```

---

## 🔧 **TROUBLESHOOTING**

### **Chatbot Tidak Berfungsi**
1. Cek API Key di file `.env`
2. Pastikan format: `GROQ_API_KEY=gsk_xxxxx...`
3. Restart server: `Ctrl+C` → `npm start`
4. Cek console di browser (F12)

### **Server Tidak Jalan**
1. Pastikan Node.js sudah terinstall: `node --version`
2. Install dependencies: `npm install`
3. Cek port 3000 tidak digunakan aplikasi lain

### **Halaman Tidak Muncul**
1. Pastikan server running (lihat terminal)
2. Buka: `http://localhost:3000` (bukan `https`)
3. Clear cache browser (Ctrl+F5)

---

## 📝 **KEUNGGULAN VERSI 3.0**

### ✅ **Halaman Tentang - Ultra Modern**
- Sejarah kampus dengan visual
- Visi & Misi dalam cards
- 6 Nilai kampus dengan icon
- Timeline perjalanan kampus
- Statistik yang menarik

### ✅ **Halaman Kontak - Profesional**
- 4 Info cards (alamat, telepon, email, jam)
- Form kontak modern
- Google Maps terintegrasi
- 5 Social media links
- Quick contact (WhatsApp, Live Chat)
- FAQ section

### ✅ **Halaman Program - Detail Lengkap**
- 4 Program studi unggulan
- Badges (S1, durasi, akreditasi)
- Detail SKS, durasi, gelar
- Prospek karir untuk setiap program
- CTA "Daftar Sekarang"

### ✅ **Halaman Fasilitas - Menarik**
- 8+ Fasilitas kampus
- Image placeholder dengan icon besar
- Fitur-fitur setiap fasilitas
- Stats overview (gedung, komputer, buku)
- Animated stats counter

---

## 🔥 **GROQ API - Kelebihan**

- ✅ **GRATIS** untuk penggunaan wajar
- ✅ **SUPER CEPAT** (fastest inference!)
- ✅ **MODEL BAGUS** (Llama 3.3 70B)
- ✅ **MUDAH SETUP** (tanpa kartu kredit)
- ✅ **GENEROUS RATE LIMIT** (14,400 req/day)

---

## 💡 **TIPS PENGGUNAAN**

1. **Customize Content** - Edit `config/campusConfig.js` untuk semua konten
2. **Test Chatbot** - Tanya berbagai pertanyaan untuk test AI
3. **Responsive Design** - Buka di HP untuk lihat tampilan mobile
4. **Social Media** - Update link social media di config
5. **Google Maps** - Ganti koordinat di `views/kontak.ejs`

---

## 📞 **SUPPORT**

Jika ada pertanyaan atau butuh bantuan:
1. Baca dokumentasi ini dengan teliti
2. Cek file `CARA-UBAH-NAMA-KAMPUS.txt`
3. Test chatbot dengan pertanyaan Anda

---

## 📜 **LICENSE**

MIT License - Bebas digunakan dan dimodifikasi

---

## 🎉 **SELAMAT!**

Website kampus Anda sudah siap! Semua halaman sudah lengkap dan modern. Enjoy! 🚀

**Made with ❤️ using Node.js, Express, EJS, and Groq AI**
