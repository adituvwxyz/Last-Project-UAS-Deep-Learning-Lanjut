const express = require('express');
const router = express.Router();
const axios = require('axios');

// Chat endpoint
router.post('/chat', async (req, res) => {
    const { message } = req.body;

    if (!message) {
        return res.status(400).json({
            success: false,
            error: 'Pesan tidak boleh kosong'
        });
    }

    try {
        const response = await axios.post(
            process.env.GROQ_API_URL,
            {
                model: 'llama-3.3-70b-versatile', // Groq model yang cepat dan bagus
                messages: [
                    {
                        role: 'system',
                        content: `Kamu adalah asisten virtual yang membantu calon mahasiswa untuk Universitas Teknologi Nusantara (UTN). 
                        Kamu ramah, informatif, dan selalu siap membantu menjawab pertanyaan tentang:
                        - Program studi yang tersedia
                        - Pendaftaran mahasiswa baru
                        - Fasilitas kampus
                        - Biaya kuliah
                        - Beasiswa
                        - Kehidupan kampus
                        Jawab dengan singkat, jelas, dan ramah dalam bahasa Indonesia.`
                    },
                    {
                        role: 'user',
                        content: message
                    }
                ],
                temperature: 0.7,
                max_tokens: 500
            },
            {
                headers: {
                    'Authorization': `Bearer ${process.env.GROQ_API_KEY}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        const botReply = response.data.choices[0].message.content;

        res.json({
            success: true,
            reply: botReply
        });

    } catch (error) {
        console.error('Error calling Groq API:', error.response?.data || error.message);
        
        res.json({
            success: true,
            reply: 'Maaf, saya sedang mengalami gangguan. Silakan coba lagi nanti atau hubungi admin melalui halaman kontak. 😊'
        });
    }
});

module.exports = router;
